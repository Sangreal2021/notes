[IntelliJ 설정]

1. spring initializr
	- Project : Gradle - Groovy
	- Language : Java
	- Spring Boot : 3.2.1
	- Project Metadata
		Group : com.example
		Artifact : rest-api
		Name : rest-api
		Description : Demo project for Spring Boot
		Package name : com.example.rest-api
		Packaging : Jar
		Java : 17
	- Dependencies
		Lombok
		Spring Web